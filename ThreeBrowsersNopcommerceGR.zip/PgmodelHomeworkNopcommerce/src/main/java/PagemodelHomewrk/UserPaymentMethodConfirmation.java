package PagemodelHomewrk;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;

/**
 * Created by Samsung on 11/22/2016.
 */
public class UserPaymentMethodConfirmation extends DriverManager {
    Utility utility=new Utility();//Calling methods Created in Utility class.

    //Below locators to enter Card details.
    @FindBy(xpath = "//td[2]/select")
    private WebElement _CreditCardTypeMasterCard;
    @FindBy(css="#CardholderName")
    private WebElement _CardHoldersName;
    @FindBy(css="#CardNumber")
    private WebElement _CardNumber;
    @FindBy(css = "#ExpireMonth")
    private WebElement _ExpiryMonth;
    @FindBy(css = "#ExpireYear")
    private WebElement _ExpiryYear;
    @FindBy(css="#CardCode")
    private WebElement _CardCode;
    @FindBy(xpath="//div[@id='payment-info-buttons-container']/input")
    private WebElement _ContinueToPaymentPage;
    @FindBy(css = "strong")
    private WebElement _YourOrderPlaced;
    @FindBy(xpath="//li[6]/div[2]/div[2]/input")
    private WebElement _CompleteOrderConfirmation;
    @FindBy(xpath = "//div[3]/input")
    private WebElement _ConfirmationDoneContinueOrLogOut;
    @FindBy(xpath = "//a[contains(text(),'Log out')]")
    private WebElement _userLogOutAfterOrdering;
    @FindBy(xpath = "/descendant::strong[contains(text(),'Your order has been successfully processed!')] ")
    private WebElement _actualResultYourOrderHasBeenSuccessfullyProcessed;

public void userEnteringPaymentDetails() throws InterruptedException {
    utility.implicitWait();
    utility.enteringText(_CardHoldersName,"gaurav");//User credit card details in below codes.
    utility.selectingByIndexValueMethod(_CreditCardTypeMasterCard,01);
    utility.enteringText(_CardNumber,"5292080308656048");
    utility.selecting(_ExpiryMonth,"01");
    utility.selecting(_ExpiryYear,"2021");
    utility.enteringText(_CardCode,"949");
    utility.clicking(_ContinueToPaymentPage);//User continues to confirm card payment filled and continue.
    utility.waitUntilElementIsThere(_CompleteOrderConfirmation);
    utility.clicking(_CompleteOrderConfirmation);//User continues to confirm order
    Assert.assertEquals("Your order has been successfully processed!",utility.getTextFromElement(_actualResultYourOrderHasBeenSuccessfullyProcessed));
    System.out.println("Test Passed");
    //System.out.println(_ThankYouForOrdering); //Below steps Can be used for further step to log out user
    //utility.clicking(_ConfirmationDoneContinueOrLogOut);
    // utility.clicking(_userLogOutAfterOrdering);
    // System.out.println("User has logged out after ordering.");
}
}
