package PagemodelHomewrk;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.support.PageFactory;

import java.util.concurrent.TimeUnit;

/**
 * Created by Samsung on 11/21/2016.
 */
public class DriverManager {

    protected static WebDriver driver;

    public DriverManager() {

        PageFactory.initElements(driver, this);

    }
    public static void openBrowser() {
        String browser = "ie";
        if (browser.equalsIgnoreCase("Chrome")) {
            System.setProperty("webdriver.chrome.driver", "src\\test\\Resources\\BrowserDriver\\chromedriver.exe");
            driver = new ChromeDriver();
            driver.manage().window().maximize();
            driver.get("http://demo.nopcommerce.com/");

        }
        if (browser.equalsIgnoreCase("ie")) {

            System.setProperty("webdriver.ie.driver", "src\\test\\Resources\\BrowserDriver\\IEDriverServer.exe");
            driver = new InternetExplorerDriver();
            driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
            driver.manage().window().maximize();
            driver.get("http://demo.nopcommerce.com/");

        } else {
            //driver = new FirefoxDriver();
          //  driver.get("http://demo.nopcommerce.com/");
        }
    }


    public static void closeBrowser(){
         driver.quit();
}
}
