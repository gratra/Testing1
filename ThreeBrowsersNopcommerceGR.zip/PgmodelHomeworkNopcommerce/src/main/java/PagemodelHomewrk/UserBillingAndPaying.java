package PagemodelHomewrk;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;

/**
 * Created by Samsung on 11/22/2016.
 */
    public class UserBillingAndPaying extends DriverManager {
    Utility utility = new Utility();//Calling methods created in Utility.

    @FindBy(css = "#BillingNewAddress_CountryId")
    private WebElement _billingCountry;
    @FindBy(css = "#BillingNewAddress_StateProvinceId")
    private WebElement _billingState;
    @FindBy(css = "#BillingNewAddress_City")
    private WebElement _billingCity;
    @FindBy(css = "#BillingNewAddress_Address1")
    private WebElement _billingAddressLine1;
    @FindBy(id = "BillingNewAddress_ZipPostalCode")
    private WebElement _billingZipCode;
    @FindBy(id = "BillingNewAddress_PhoneNumber")
    private WebElement _billingPhoneNumber;
    @FindBy(xpath = "//input[@value='Continue']")
    private WebElement _continueNextPageAddressShipping;
    @FindBy(xpath="//form/div[2]/input")
    private WebElement _shippingAddressConfirmed;
    @FindBy(id = "paymentmethod_1")
    private WebElement _creditCardSelectionButton;
    @FindBy(xpath = "//div[@id='payment-method-buttons-container']/input")
    private WebElement _continuesButtonBeforeCCInfoPage;
    @FindBy(css ="td > label" )
    private WebElement _selectCreditCardText;

    public void userBillingInfo() throws InterruptedException {
        utility.implicitWait();
        ((JavascriptExecutor)driver).executeScript("scroll(0,400)");
        utility.selecting(_billingCountry, "United States");//Below codes user adds billing and shipping information.
        utility.selecting(_billingState, "AA (Armed Forces Americas)");
        utility.enteringText(_billingCity, "California");
        utility.enteringText(_billingAddressLine1, "California City");
        utility.enteringText(_billingZipCode, "123456789");
        utility.enteringText(_billingPhoneNumber, "009000000000");
        utility.clicking(_continueNextPageAddressShipping);//User continues with same shipping and billing address
        utility.waitUntilElementIsThere(_shippingAddressConfirmed);
        utility.clicking(_shippingAddressConfirmed);
        utility.clicking(_creditCardSelectionButton);//User confirms wants to pay by Credit Card.
        utility.clicking(_continuesButtonBeforeCCInfoPage);//User confirms and continues to Proceed for Payment.
        Assert.assertEquals("Select credit card",utility.getTextFromElement(_selectCreditCardText),"User not on Payment Page");
        //Asserted above to check User on correct page ready to select card payment.
    }
}
