package PagemodelHomewrk;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.TimeUnit;

/**
 * Created by Samsung on 11/21/2016.
 */
public class Utility extends DriverManager {

    public static void clicking(WebElement element) {
        element.click();

    }

    public static void enteringText(WebElement element, String text) {
        element.sendKeys(text);
    }

    public String getTextFromElement(WebElement element) {
        String txt = element.getText();
        return txt;
    }

 //   public String gettingAttributeFromElement(WebElement element) {
    //    String txt = element.getAttribute("");
    //    return txt;
  //  }

  //  public static void waitingForElement(WebElement element) {
      //  element.isEnabled();
   // }

    public static String randomDate() {
        DateFormat format = new SimpleDateFormat("ddMMMyyHHmmss");
        return format.format(new Date());
    }

    public String emailGenerated(WebElement _usersEmailAddress) {
        String email = "gauravratra" + randomDate() + "@123.com";// could not use two together
        return email;
    }


    public void implicitWait() {
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

    }

    public void explicitWaitInput(WebElement element) {
        WebDriverWait wait = new WebDriverWait(driver, 10);
        WebElement element1 = wait.until(ExpectedConditions.elementToBeClickable(element));

    }

    public String selecting(WebElement element, String text) {
        new Select(element).selectByVisibleText(text);

        return text;
    }

    public void selectingByIndexValueMethod(WebElement element,int a){
             Select select=new Select(element);
        select.selectByIndex(a);




    }

    //public void doubleClickingOnElement(WebElement element) {
    //    Actions action = new Actions(driver);
     //   action.moveToElement(element).doubleClick().perform();
//Mouse over
        // action.moveToElement(element).perform();

//Right Click
        // action.contextClick(element).perform();
 //   }

    public void mouseHoverActionCreated(WebElement element) {
        WebElement ele = element;
        Actions action = new Actions(driver);
        action.moveToElement(ele).perform();

    }

    public void waitUntilElementIsThere(WebElement element) {
        WebElement element1 = (new WebDriverWait(driver, 15))
                .until(ExpectedConditions.elementToBeClickable(element));

    }
}


