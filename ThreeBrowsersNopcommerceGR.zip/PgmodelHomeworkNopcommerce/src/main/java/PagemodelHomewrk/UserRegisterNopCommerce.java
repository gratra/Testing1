package PagemodelHomewrk;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;

/**
 * Created by Samsung on 11/21/2016.
 */
public class UserRegisterNopCommerce extends DriverManager {
    Utility utility=new Utility();//Calling methods created in Utility class.

    // Below are the locators required for log in page
    @FindBy(css="a.ico-register")
    private WebElement _registerLink;
    @FindBy(id = "FirstName")
    private WebElement _userName;
    @FindBy(id = "LastName")
    private WebElement _userLastName;
    @FindBy(id = "Email")
    private WebElement _usersEmailAddress;
    @FindBy(id = "Password")
    private WebElement _userPassword;
    @FindBy(id = "ConfirmPassword")
    private WebElement _userConfirmPassword;
    @FindBy(id ="register-button")
    private WebElement _registerButtonToConfirm;
    @FindBy(className = "result")
    private WebElement _userHasRegisteredConfirmation;


    public void registerForm() {
        //       utility.waitingForElement(_registerLink);
        //driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);

        utility.implicitWait();
        utility.clicking(_registerLink);  //user clicks on register link to start filling form
        utility.enteringText((_userName),"Tgaurav");//user completing form in eg.firstName,lastName,email,passwords below-
        utility.enteringText((_userLastName),"Tratra");
        utility.enteringText((_usersEmailAddress),"gauravratra"+utility.randomDate()+"@123.com");
        utility.enteringText((_userPassword),"abc123456789");
        utility.enteringText((_userConfirmPassword),"abc123456789");
        utility.clicking((_registerButtonToConfirm));//user clicks on register button after completing form

        Assert.assertEquals(("Your registration completed"),utility.getTextFromElement(_userHasRegisteredConfirmation),"User has not registered");
        //Above Assert done to confirm user has registered successfully
    }
}