package PagemodelHomewrk;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;

import java.util.concurrent.TimeUnit;

/**
 * Created by Samsung on 11/21/2016.
 */
public class UserAddingTwoProductsInCart extends DriverManager {

    Utility utility=new Utility();//Calling Utility by creating object reference
    //Below are the locators for continue to shop and add products in cart.
    @FindBy (xpath="//a[contains(@href, '/electronics')]")
    private WebElement _continueToShop;
    @FindBy(linkText = "Electronics")
    private WebElement _electronics;
    @FindBy(xpath = "(//a[contains(@href, '/cell-phones')])[3]")
    private WebElement _cellphones;
    @FindBy(xpath = "//div[2]/div/div[2]/div[3]/div[2]/input")
    private WebElement _addHtcPhoneProduct;
    @FindBy(css="p.content")
    private WebElement _AssertingItem1Added;
    @FindBy(css = "span.close")
    private WebElement _closingAndContinue;
    @FindBy(xpath="//div/div/div[2]/ul/li[5]/a")
    private WebElement _books;
    @FindBy(xpath="(//input[@value='Add to cart'])[2]")
    private WebElement _addBookProduct;
    @FindBy(xpath = "//li[@id='topcartlink']/a/span")
    private WebElement _shoppingCartTab;
    @FindBy(css="#CountryId")
    private WebElement _selectCountryOption;
    @FindBy(css = "#StateProvinceId")
    private WebElement _stateProvince;
    @FindBy(css="#termsofservice")
    private WebElement _checkingTermsofService;
   @FindBy(xpath = "//button[@id='checkout']")
    private WebElement _checkoutBoxAfterTermsofService;
    @FindBy (xpath="html/body/div[5]/div[1]/div[1]/div[2]/div[2]/div/div[4]/input")   //(xpath ="//input[@value='Go to cart']")
    private WebElement _goTOCartPage;
    @FindBy(tagName = "h1")
     private WebElement _checkOutPageStarts;


     public void userShopping() throws InterruptedException {
         utility.implicitWait();
       //  driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
         utility.clicking(_continueToShop);//User Continues to shop.
         utility.clicking(_electronics);//Below codes for User to add cellPhone product one in cart.
         ((JavascriptExecutor)driver).executeScript("scroll(0,400)");
         utility.clicking(_cellphones);
         ((JavascriptExecutor)driver).executeScript("scroll(0,400)");
         utility.clicking(_addHtcPhoneProduct);
         Assert.assertEquals("The product has been added to your shopping cart",utility.getTextFromElement(_AssertingItem1Added),"Item has not been added to cart");
         utility.clicking(_closingAndContinue);
         ((JavascriptExecutor)driver).executeScript("scroll(0,400)");//Used to scroll to locate element on page.
         utility.clicking(_books);//Below codes for User to add books product two in cart.
         utility.clicking(_addBookProduct);
         Assert.assertEquals("The product has been added to your shopping cart",utility.getTextFromElement(_AssertingItem1Added),"Item has not been added to cart");
         utility.clicking(_closingAndContinue);
         ((JavascriptExecutor)driver).executeScript("scroll(0,400)");
         driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
         utility.mouseHoverActionCreated(_shoppingCartTab);//User goes to Shopping basket
         utility.waitUntilElementIsThere(_goTOCartPage);
         utility.clicking(_goTOCartPage); //User goes to Cart
         ((JavascriptExecutor)driver).executeScript("scroll(0,400)");
         utility.selecting(_selectCountryOption,"United States");//User adding and agreeing services to proceed.
         utility.selecting(_stateProvince,"Arizona");
         utility.clicking(_checkingTermsofService);
         utility.clicking(_checkoutBoxAfterTermsofService);
         Assert.assertEquals("Checkout",utility.getTextFromElement(_checkOutPageStarts),"User not on checkout page");

     }

        }
