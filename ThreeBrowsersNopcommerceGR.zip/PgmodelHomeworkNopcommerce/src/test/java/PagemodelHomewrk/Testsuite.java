package PagemodelHomewrk;

import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

/**
 * Created by Samsung on 11/21/2016.
 */
public class Testsuite extends DriverManager {
    UserRegisterNopCommerce register = new UserRegisterNopCommerce();
      UserAddingTwoProductsInCart shoppingTwoProducts = new UserAddingTwoProductsInCart();
     UserBillingAndPaying userBilling = new UserBillingAndPaying();
    UserPaymentMethodConfirmation userPaying = new UserPaymentMethodConfirmation();


    @BeforeTest
    public static void OpeningBrowser() {

        DriverManager.openBrowser();//Opens the NopCommerce website before test
    }

    @AfterTest
    public static void closingBrowser() {

        DriverManager.closeBrowser();//Close NopCommerce website after test.
    }

//    //    @Test //Test just to check User able to register.
//public void userRegistering() throws InterruptedException {
//
//    UserRegisterNopCommerce register = new UserRegisterNopCommerce();
//    register.registerForm();
//}
//
////     @Test  //Test to check user able to register + adding products
//
//public void userAddsTwoProducts()  {
//
//    UserRegisterNopCommerce register = new UserRegisterNopCommerce();
//    UserAddingTwoProductsInCart shoppingTwoProducts = new UserAddingTwoProductsInCart();
//    register.registerForm();
//    shoppingTwoProducts.userShopping()  ;    }
//
//@Test //Test to check User register+adding products to shopping cart+billing information.
//
//public void userBillingInformation()  {
//    UserRegisterNopCommerce register = new UserRegisterNopCommerce();
//    UserAddingTwoProductsInCart shoppingTwoProducts = new UserAddingTwoProductsInCart();
//    UserBillingAndPaying userBilling = new UserBillingAndPaying();
//    register.registerForm();
//    shoppingTwoProducts.userShopping();
//    userBilling.userBillingInfo();
//}
//


        @Test    //Test for end to end scenario of user register to payment.
        public  void payingForProducts () throws InterruptedException {
            UserRegisterNopCommerce register = new UserRegisterNopCommerce();
            UserAddingTwoProductsInCart shoppingTwoProducts = new UserAddingTwoProductsInCart();
            UserBillingAndPaying userBilling = new UserBillingAndPaying();
            UserPaymentMethodConfirmation userPaying = new UserPaymentMethodConfirmation();


            register.registerForm();
            shoppingTwoProducts.userShopping();
            userBilling.userBillingInfo();
            userPaying.userEnteringPaymentDetails();


        }


}




