package CucumberNop;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;

/**
 * Created by Samsung on 11/30/2016.
 */
public class ContinueSendingEmail extends DriveManager {
    Utility utility=new Utility();
    @FindBy(name="register-continue")
    private WebElement _ContinueAfterRegister;
    @FindBy(xpath = "//a[contains(@href, '/computers')]")
    private WebElement _computerProducts;
    @FindBy(xpath = "(//a[contains(text(),'Desktops')])[3]")
    private WebElement _desktopsOptionSelected;
    @FindBy(xpath ="//div[3]/div/div/div/div/a/img")
    private WebElement _desktopSelected;
    @FindBy(xpath = "//form[@id='product-details-form']/div/div/div[2]/div[10]/div[3]/input")
    private WebElement _sendEmailOptionOfDesktop;
    @FindBy(id = "FriendEmail")
    private WebElement _friendsEmailInput;
    @FindBy(xpath="//form/div[2]/input")
    private WebElement _sendEmailButtonConfirm;
    @FindBy(xpath = "//div[3]/div/div/div/div[2]/div[2]")
    private WebElement _emailSentConfirmationStatement;

    public void userClicksContinue() {
        utility.ImplicitWait();
        utility.clickingOnElement(_ContinueAfterRegister);//User clicks on continues to send email.
    }
    public void useSelectsProduct() {
        utility.clickingOnElement(_computerProducts);//User selects a product in order to use email a friend feature.
        utility.clickingOnElement(_desktopsOptionSelected);
        ((JavascriptExecutor) driver).executeScript("scroll(0,400)");
        utility.clickingOnElement(_desktopSelected);
        ((JavascriptExecutor) driver).executeScript("scroll(0,400)");
        utility.clickingOnElement(_sendEmailOptionOfDesktop);
    }
    public void userEntersEmailDetails() {
        utility.enteringText(_friendsEmailInput, "testertrainee@gmail.com");//User enters any valid email to send email.
    }public void userClicksSendButton() {

        utility.clickingOnElement(_sendEmailButtonConfirm);
    }
    public void userCanSeeMessage(){
        Assert.assertEquals(_emailSentConfirmationStatement.getText(),"Your message has been sent.","Email Not Sent");
    }

}
