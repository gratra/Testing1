package CucumberNop;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.TimeUnit;

/**
 * Created by Samsung on 11/29/2016.
 */
public class Utility extends DriveManager {


    public void clickingOnElement(WebElement element){
        element.click();
    }
    public void enteringText(WebElement element,String text){
        element.sendKeys(text);
    }
    public void ImplicitWait(){
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
    }
    public void waitUntilElementIsThere(WebElement element) {
        WebElement element1 = (new WebDriverWait(driver, 15))
                .until(ExpectedConditions.elementToBeClickable(element));

    }
    public static String randomDate() {
        DateFormat format = new SimpleDateFormat("ddMMMyyHHmmss");
        return format.format(new Date());
    }

    public String emailGenerated(WebElement _usersEmailAddress) {
        String email = "gauravratra" + randomDate() + "@123.com";// could not use two together
        return email;
    }
    public String getTextFromElement(WebElement element) {
        String txt = element.getText();
        return txt;
    }
}


