package CucumberNop;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import static CucumberNop.Utility.randomDate;

/**
 * Created by Samsung on 12/1/2016.
 */
public class AlreadyRegisteredUser extends DriveManager {
    Utility utility=new Utility();

    // Below are the locators required for log in page
    @FindBy(linkText = "Register")
    private WebElement _registerLink;
    @FindBy(id = "FirstName")
    private WebElement _userName;
    @FindBy(id = "LastName")
    private WebElement _userLastName;
    @FindBy(id = "Email")
    private WebElement _usersEmailAddress;
    @FindBy(id = "Password")
    private WebElement _userPassword;
    @FindBy(id = "ConfirmPassword")
    private WebElement _userConfirmPassword;
    @FindBy(id = "register-button")
    private WebElement _registerButtonToConfirm;
    @FindBy(className = "result")
    private WebElement _userHasRegisteredConfirmation;

    public void registerFormForSendingEmail() throws InterruptedException {

         utility.ImplicitWait();
        utility.clickingOnElement(_registerLink);  //user clicks on register link to start filling form.
        utility.enteringText(_userName, "AbcGaurav");//user completing form in eg.firstName,lastName,email,passwords below-
        utility.enteringText(_userLastName, "Ratra");
        utility.enteringText(_usersEmailAddress, "gauravratra" + randomDate() + "@123.com");
        utility.enteringText(_userPassword, "abc123456789");
        utility.enteringText(_userConfirmPassword, "abc123456789");
        utility.waitUntilElementIsThere(_registerButtonToConfirm);
        utility.clickingOnElement(_registerButtonToConfirm);//user clicks on register button after completing form
    }
    }