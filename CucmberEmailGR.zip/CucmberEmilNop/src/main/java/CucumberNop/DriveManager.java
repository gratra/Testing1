package CucumberNop;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.support.PageFactory;

/**
 * Created by Samsung on 11/29/2016.
 */
public class DriveManager {
    protected static WebDriver driver;

    public DriveManager() {
        PageFactory.initElements(driver, this);
    }

    public static void openBrowser() {
        String browser = "ie";
        if (browser.equalsIgnoreCase("chrome")) {
            System.setProperty("webdriver.chrome.driver", "src\\test\\Resources\\BrowserDriver\\chromedriver.exe");
            driver = new ChromeDriver();
            driver.manage().window().maximize();
            driver.get("http://demo.nopcommerce.com/");
        }
        if (browser.equalsIgnoreCase("ie")) {
            System.setProperty("webdriver.ie.driver", "src\\test\\Resources\\BrowserDriver\\IEDriverServer.exe");
            driver = new InternetExplorerDriver();
            driver.manage().window().maximize();
            driver.get("http://demo.nopcommerce.com/");
        }


        else

    {
       // driver = new FirefoxDriver();
       // driver.manage().window().maximize();
     //   driver.get("http://demo.nopcommerce.com/");
    }

}
    public static void closeBrowser(){
        driver.quit();





    }
}
