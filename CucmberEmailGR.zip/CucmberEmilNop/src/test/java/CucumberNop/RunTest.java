package CucumberNop;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import org.junit.runner.RunWith;

/**
 * Created by Samsung on 11/29/2016.
 */
@RunWith(Cucumber.class)
@CucumberOptions(features="C:\\Users\\Samsung\\IdeaProjects\\CucmberEmilNop\\src\\test\\features\\emaiFriend.feature")


public class RunTest extends DriveManager {

}
