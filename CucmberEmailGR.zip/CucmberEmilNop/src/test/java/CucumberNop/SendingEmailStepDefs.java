package CucumberNop;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

/**
 * Created by Samsung on 11/30/2016.
 */
public class SendingEmailStepDefs extends DriveManager {


    @Given("^User already registered clicks on continue$")
    public void user_already_registered_clicks_on_continue() throws InterruptedException {


        openBrowser();

    }


    @When("^user goes to computers and selects products$")
    public void user_goes_to_computers_and_selects_products() throws InterruptedException {
        AlreadyRegisteredUser registers=new AlreadyRegisteredUser();
        ContinueSendingEmail continueToMail=new ContinueSendingEmail();
        ContinueSendingEmail goesToSelect=new ContinueSendingEmail();
        registers.registerFormForSendingEmail();
        continueToMail.userClicksContinue();
        goesToSelect.useSelectsProduct();
    }

    @When("^user clicks on email a friend and enter details$")
    public void user_clicks_on_email_a_friend_and_enter_details() throws Throwable {
ContinueSendingEmail emailFreind=new ContinueSendingEmail();
        emailFreind.userEntersEmailDetails();
    }

    @When("^user clicks on send email$")
    public void user_clicks_on_send_email() {
       ContinueSendingEmail sendEmail=new ContinueSendingEmail();
        sendEmail.userClicksSendButton();
    }

    @Then("^user should see message your email has been sent successfully$")
    public void user_should_see_message_your_email_has_been_sent_successfully() {
ContinueSendingEmail messageSent=new ContinueSendingEmail();
        messageSent.userCanSeeMessage();
               closeBrowser();
    }


}
