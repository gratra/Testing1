package Cucumber;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

/**
 * Created by Samsung on 12/1/2016.
 */
public class Utility extends DriveManager{

    public static void clicking(WebElement element){

        element.click();

    }
    public static void enterText(WebElement element,String text){

        element.sendKeys(text);

    }

    public static String getTextFrom(WebElement element){

        String text=element.getText();
        return text;

    }
    public static void waitUntilElementIsThere(WebElement element){

        WebElement element1=(new WebDriverWait(driver,15)).until(ExpectedConditions.elementToBeClickable(element));

    }
}
