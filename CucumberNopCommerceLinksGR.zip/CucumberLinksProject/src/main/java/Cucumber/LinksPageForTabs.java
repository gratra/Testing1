package Cucumber;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;

/**
 * Created by Samsung on 12/1/2016.
 */
public class LinksPageForTabs extends DriveManager {
    Utility utility = new Utility();
    //Below are locators for the links of heading tabs
    @FindBy(xpath = "//div[2]/ul/li/a")
    private WebElement _computerLink;
    @FindBy(xpath = "//h1")
    private WebElement _actualComputer;
    @FindBy(xpath = "//div[2]/ul/li[2]/a")
    private WebElement _electronicsLink;
    @FindBy(xpath = "//h1")
    private WebElement _actualElectronics;
    @FindBy(xpath = "//div[2]/ul/li[3]/a")
    private WebElement _apparelLink;
    @FindBy(xpath = "//h1")
    private WebElement _actualApparel;
    @FindBy(xpath = "//div[2]/ul/li[4]/a")
    private WebElement _digitalDownloadLink;
    @FindBy(xpath = "//h1")
    private WebElement _actualDigitalDownload;
    @FindBy(xpath = "//li[5]/a")
    private WebElement _booksLink;
    @FindBy(xpath = "//h1")
    private WebElement _actualBooks;
    @FindBy(xpath = "//li[6]/a")
    private WebElement _jeweleryLink;
    @FindBy(xpath = "//h1")
    private WebElement _actualJewelery;
    @FindBy(xpath = "//li[7]/a")
    private WebElement _giftCardsLink;
    @FindBy(xpath = "//h1")
    private WebElement _actualGiftCards;


    public void verifyingComputerLink() {
        utility.clicking(_computerLink);
    }

    public void assertingComputerLink() {
        utility.waitUntilElementIsThere(_actualComputer);
        Assert.assertEquals(_actualComputer.getText(),"Computers", "Not on Correct page");
        closeBrowser();
    }

    public void verifyingElectronicsLink() {
        utility.clicking(_electronicsLink);
    }

    public void assertingElectronicsLink() {
        Assert.assertEquals(_actualElectronics.getText(), "Electronics", "Not on Correct page");
        closeBrowser();

    }

    public void verifyingApparelLink() {
        utility.clicking(_apparelLink);
    }

    public void assertingApparelLink() {
        Assert.assertEquals(_actualApparel.getText(), "Apparel", "Not on Correct page");
        closeBrowser();

    }

    public void verifyingDigitalDownloadsLink() {
        utility.clicking(_digitalDownloadLink);
    }

    public void assertingDigitalDownload() {
        Assert.assertEquals(_actualDigitalDownload.getText(), "Digital downloads", "Not on Correct page");
        closeBrowser();
    }

    public void verifyingBooksLink() {
        utility.clicking(_booksLink);
    }

    public void assertingBooks() {
        Assert.assertEquals(_actualBooks.getText(), "Books", "Not on Correct page");
        closeBrowser();
    }

    public void verifyingJewelryLink() {
        utility.clicking(_jeweleryLink);
    }

    public void assertingJewelry() {
        Assert.assertEquals(_actualJewelery.getText(), "Jewelry", "Not on Correct page");
        closeBrowser();

    }

    public void verifyingGiftCardsLink() {
        utility.waitUntilElementIsThere(_giftCardsLink);
        utility.clicking(_giftCardsLink);
    }

    public void assertingGiftCards() {
        Assert.assertEquals(_actualGiftCards.getText(), "Gift Cards", "Not on Correct page");
        closeBrowser();


    }
}

