package Cucumber;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import org.junit.runner.RunWith;

/**
 * Created by Samsung on 12/1/2016.
 */
@RunWith(Cucumber.class)
@CucumberOptions(features ="src\\test\\Resources\\features\\links.feature" )
public class RunTest extends DriveManager {






}
