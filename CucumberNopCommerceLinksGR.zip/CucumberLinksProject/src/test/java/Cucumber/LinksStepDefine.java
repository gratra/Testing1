package Cucumber;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

/**
 * Created by Samsung on 12/1/2016.
 */
public class LinksStepDefine {
    @Given("^User opens browser and goes to nopCommerce$")
    public void user_opens_browser_and_goes_to_nopCommerce() {
        DriveManager.openBrowser();

    }

    @When("^User clicks on Computer Link$")
    public void user_clicks_on_Computer_Link(){
        LinksPageForTabs verifying=new LinksPageForTabs();
        verifying.verifyingComputerLink();

    }

    @Then("^User should see page with computers$")
    public void user_should_see_page_with_computers() {
        LinksPageForTabs asserting=new LinksPageForTabs();

        asserting.assertingComputerLink();


    }

    @When("^User clicks on Electronics Link$")
    public void user_clicks_on_Electronics_Link()  {
        LinksPageForTabs verifying=new LinksPageForTabs();
        verifying.verifyingElectronicsLink();

    }

    @Then("^User should see page with Electronics$")
    public void user_should_see_page_with_Electronics()  {
        LinksPageForTabs asserting=new LinksPageForTabs();
        asserting.assertingElectronicsLink();

    }

    @When("^User clicks on Apparel Link$")
    public void user_clicks_on_Apparel_Link()  {
        LinksPageForTabs verifying=new LinksPageForTabs();
           verifying.verifyingApparelLink();
    }

    @Then("^User should see page with Apparel$")
    public void user_should_see_page_with_Apparel()  {
        LinksPageForTabs asserting=new LinksPageForTabs();
        asserting.assertingApparelLink();
    }

    @When("^User clicks on Digital downloads Link$")
    public void user_clicks_on_Digital_downloads_Link()  {
        LinksPageForTabs verifying=new LinksPageForTabs();
        verifying.verifyingDigitalDownloadsLink();
    }

    @Then("^User should see page with Digital downloads$")
    public void user_should_see_page_with_Digital_downloads()  {
        LinksPageForTabs asserting=new LinksPageForTabs();
        asserting.assertingDigitalDownload();
    }

    @When("^User clicks on Books Link$")
    public void user_clicks_on_Books_Link()  {
        LinksPageForTabs verifying=new LinksPageForTabs();
        verifying.verifyingBooksLink();
    }

    @Then("^User should see page with Books$")
    public void user_should_see_page_with_Books()  {
        LinksPageForTabs asserting=new LinksPageForTabs();
        asserting.assertingBooks();
    }

    @When("^User clicks on Jewelry Link$")
    public void user_clicks_on_Jewelry_Link()  {
        LinksPageForTabs verifying=new LinksPageForTabs();
        verifying.verifyingJewelryLink();
    }

    @Then("^User should see page with Jewelry$")
    public void user_should_see_page_with_Jewelry() {
        LinksPageForTabs asserting=new LinksPageForTabs();
        asserting.assertingJewelry();
    }

    @When("^User clicks on Gift Cards Link$")
    public void user_clicks_on_Gift_Cards_Link()  {
        LinksPageForTabs verifying=new LinksPageForTabs();
        verifying.verifyingGiftCardsLink();

    }

    @Then("^User should see page with Gift Cards$")
    public void user_should_see_page_with_Gift_Cards()  {
        LinksPageForTabs asserting=new LinksPageForTabs();
        asserting.assertingGiftCards();
    }

}
